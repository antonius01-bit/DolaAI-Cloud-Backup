# 📚 DOLA AI & ANTIGRAVITY — MASTER SKILL REGISTRY & HOW-TO-USE GUIDE
> **Omni-Auto v3.2 · 105+ Base Skills + Autonomous GitHub Skill Harvester & Super-Skills**
> **Location**: Permanent Global Plugin (`~/.gemini/config/plugins/dola-ai/`) & Local Workspace (`C:\Users\antoni\Dola\`)

---

## ⚡ 1. OMNI-AUTO & ACADEMIC MASTER SUITE (v3.2)

| # | Skill Name | Kategori | Sumber / Origin | Deskripsi & Superpowers | Cara Pakai (Perintah / Prompt / Trigger) | Status |
|---|---|---|---|---|---|---|
| **S1** | `omni-auto` | Academic Master | Dola AI Core v3.2 | Otomatisasi tesis/jurnal 100% dari awal sampai akhir → 2 naskah DOCX (ID+EN), 1 slide PPTX, dan 1 Mendeley RIS dengan sitasi `[N#E]` yang terhubung otomatis. | `/omni-auto [Thesis/Journal]: [Judul]. Tipe: [KUANTITATIF/KUALITATIF/CAMPURAN]. Variabel: [A, B]. Wilayah: [Jawa Timur]. Tahun: [2022-2024]` | ✅ AKTIF & PERMANEN |
| **S2** | `publication-shield` | Quality & Ethics | Dola AI (FK-16/17/19) | Tripel proteksi: FK-16 (Similarity $\le 5\%$), FK-17 (Pindai 29 pola AI & humanisasi kalimat), FK-19 (Verifikasi keaslian sitasi & DOI nyata). | `Audit manuscript: [file/teks] with Publication Shield. Check similarity, AI clichés, and verify all citations.` | ✅ AKTIF & PERMANEN |
| **S3** | `mendeley-ris-linker` | Reference Tech | Dola AI Citation Sync | Generate file `.ris` yang nomor `ID` nya cocok 100% dengan penomoran klaim `[1#E]`, `[2#E]` di dokumen DOCX. Sekali import ke Mendeley langsung match. | `"Generate RIS file for Mendeley from these references: [daftar/teks]"` | ✅ AKTIF & PERMANEN |
| **S4** | `master-journal-tracking` | Editorial Master | Dola AI Tracker | Matriks komentar reviewer, balasan sopan poin-per-poin, diff revisi naskah, dan audit status pengiriman jurnal. | `Manage reviewer comments for [journal]: [paste feedback] and generate point-by-point response letter.` | ✅ AKTIF & PERMANEN |
| **S5** | `markitdown-academic-parser` | Doc Parsing | Microsoft MarkItDown + Dola | Ekstraksi dokumen kompleks DOCX, PPTX, XLSX, PDF, dan transkrip audio/video menjadi format Markdown bersih tanpa merusak struktur dan formula. | `Convert [file.docx/pdf/pptx] to clean markdown with table and citation preservation.` | ✅ SUPERCHARGED |

---

## 🚀 2. ENGINEERING, AI & MCP SUPER-SKILLS (FUSED & COMBINED)

| # | Skill Name | Kategori | Sumber / Upgraded From | Deskripsi & Superpowers | Cara Pakai (Perintah / Prompt / Trigger) | Status |
|---|---|---|---|---|---|---|
| **S6** | `github-skill-harvester` | Autonomous Engine | Dola Auto-Harvester v3.2 | Scan URL GitHub, trending repo, atau MCP list → Analisis kualitas → Gabung jika mirip → Generate `SKILL.md` permanen → Update tabel log. | `Harvest skills from: https://github.com/trending and https://github.com/modelcontextprotocol/servers. Extract, combine, and save permanently.` | ✅ AKTIF & PERMANEN |
| **S7** | `agentic-engineering-suite` | Software Engineering | Superpowers + ECC + Karpathy | Standar rekayasa software tingkat tinggi: hipotesis debugging, perubahan bedah minimal (surgical diffs), verifikasi bertahap, zero-regression. | `Apply agentic engineering: Refactor [component/file] with hypothesis verification and minimal surgical diffs.` | ✅ FUSED & UPGRADED |
| **S8** | `super-browser-mcp` | Web Automation | Browser-Use + Chrome DevTools | Otomatisasi browser visual, ekstraksi multi-halaman SPA, pengelolaan sesi login, form auto-fill, dan diagnosa console/network payload. | `Automate browser: Navigate to [URL], extract table data, fill form, and verify result with screenshots.` | ✅ FUSED & UPGRADED |
| **S9** | `master-senior-software-engineer` | Software Arch | Dola Master M1 | Desain arsitektur bersih, refactoring modular, prinsip Ponytail, penulisan unit test ketat, dan optimasi performa backend/frontend. | `Architect clean code solution for [feature] following senior software engineering best practices.` | ✅ AKTIF & PERMANEN |
| **S10** | `master-ai-ml-engineer` | AI / ML Master | Dola Master M2 (Unsloth, Axolotl, DSPy) | Fine-tuning LoRA/QLoRA model bahasa, pipeline DSPy teleprompter, orkestrasi inferensi lokal (Ollama/vLLM) dan cloud API fallback. | `Optimize model pipeline using DSPy / fine-tune with Unsloth on dataset [data].` | ✅ AKTIF & PERMANEN |
| **S11** | `mcp-ecosystem-integrator` | Tool Integration | Model Context Protocol Hub | Integrasi dan manajemen server MCP (PostgreSQL, SQLite, GitHub, Brave Search, Filesystem, Slack) ke dalam `mcp_config.json`. | `Connect MCP server [name/package] and expose tools for database queries and web operations.` | ✅ AKTIF & PERMANEN |

---

## 👑 3. DOLA MASTER & MAJOR SKILLS SUMMARY (105 SKILLS)

### Master Skills (M1–M7)
- `M1: master-senior-software-engineer`: Clean code, minimal diffs, robust testing.
- `M2: master-ai-ml-engineer`: DSPy, Unsloth, Axolotl, LoRA/QLoRA fine-tuning.
- `M3: master-product-growth-analytics`: User research, data insights, SEO growth.
- `M4: master-career-resume-suite`: ATS optimization, STAR methodology, CV writing.
- `M5: master-agency-orchestrator`: Multi-agent orchestration, reality checking.
- `M6: master-journal-tracking`: Manuscript revision tracking, rebuttal letters.
- `M7: master-omni-adapter`: Style, depth, tone, and multi-provider adaptation.

### Major System Skills (1–43)
- **Penalaran & Analisis (1–7)**: `THINK`, `RESEARCH`, `REVIEW`, `VERIFY`, `LEARN`, `SUMMARIZE`, `SYNTHESIZE`.
- **Penulisan & Akademik (8–18)**: `WRITE`, `POLISH`, `CITATION`, `TEMPLATE`, `REVISE`, `RESPOND`, `HUMANIZE`, `TRANSLATE`, `ABSTRACT`, `KEYWORDS`, `REFERENCE-CHECK`.
- **Sistem & Otomasi (19–28)**: `OMNI-ROUTE`, `ENV-SETUP`, `KEY-MANAGE`, `FILE-ORGANIZE`, `GIT-TRACK`, `BATCH-PROCESS`, `PATH-CHECK`, `DUPLICATE-FIND`, `AUTO-FIX`, `MULTI-LANG`.
- **Integrasi & AI (29–36)**: `MULTICA-ADAPT`, `MODEL-SELECT`, `FREE-PRIORITY`, `API-TEST`, `SKILL-INSTALL`, `SKILL-MERGE`, `PROMPT-ENGINEER`, `AGENTIC-WORKFLOW`.
- **Utilitas & Keamanan (37–43)**: `EXCEL-MCP`, `BROWSER-MCP`, `PROMPT-MASTER`, `FREE-LLM-DIR`, `ROUTER-9`, `DARIO-ROUTE`, `AUTO-SKILL`.

### Public, Private & MCP Skills (P1–P22, R1–R12, K1–K12, G1–G9)
- `GhidraGPT`, `Obsidian-Skills`, `NotebookLM-Skill`, `Context-Engineering`, `Anthropic-Skills`, `Knowledge-Work-Plugins`, `LanguageTool`, `DeepSeek-Harness`, `Awesome-LLM-Apps`, `Superpowers`, `ECC`, `Browser-Use`, `MarkItDown`.
- Private: `OMNI-AUTO`, `JOURNAL-TRACKER`, `RIS-REFERENCE`, `DUPLICATE-REMOVE`, `PATH-VERIFY`, `DIFF-REVIEW`, `FREE-FIRST`, `KEY-ROTATE`, `MULTI-MODE`, `CONTEXT-FIT`, `ACADEMIC-TONE`, `CROSS-REFER`.
- Gateways: `dola-seed-2-0-pro`, `dola-seed-2-0-lite`, `dola-seed-2-0-mini`, `dola-seed-2-0-code`, `chatgpt_chat`, `claude_chat`, `qwen_chat`, `codex_code`, `ollama_chat`.


---

## 🌐 4. NEWLY HARVESTED GITHUB & TRENDING SKILLS (AUTONOMOUS HARVESTER)

| # | Skill Name | Kategori | Sumber / Origin | Deskripsi & Superpowers | Cara Pakai (Perintah / Prompt / Trigger) | Status |
|---|---|---|---|---|---|---|
| **S12** | `langgraph-orchestrator` | Agentic Architecture | [https://github.com/langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) | Multi-agent cyclic state-machine orchestration with checkpointing, human-in-the-loop validation, and fault-tolerant branching. | `Design stateful multi-agent workflow for [task] using LangGraph state graphs, node execution, and checkpoint memory.` | ✅ HARVESTED & ACTIVE |
| **S13** | `pydantic-ai-structured-output` | AI / ML Integration | [https://github.com/pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | Type-safe structured output generation, dynamic system prompts, and strict runtime validation for LLM responses and function calling. | `Enforce type-safe structured output for [function/schema] using Pydantic-AI models and validation hooks.` | ✅ HARVESTED & ACTIVE |
| **S14** | `openclaw-personal-assistant` | Autonomous OS Agent | [https://github.com/openclaw/openclaw](https://github.com/openclaw/openclaw) | Autonomous local task execution, background worker management, cross-application automation, and self-improving skill creation. | `Execute autonomous desktop task [task description] with OpenClaw background worker and step verification.` | ✅ HARVESTED & ACTIVE |
| **S15** | `trends-mcp-intelligence` | Live Data & Intelligence | [https://github.com/modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) | Real-time GitHub trending, tech radar analytics, and developer social signal intelligence via Model Context Protocol. | `Fetch live GitHub trending repositories and tech signals for [topic/language] via Trends MCP.` | ✅ HARVESTED & ACTIVE |
