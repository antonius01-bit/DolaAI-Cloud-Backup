---
name: openclaw-personal-assistant
description: >-
  Autonomous local task execution, background worker management, cross-application automation, and self-improving skill creation.
---

# ⚡ OpenClaw Autonomous Task Executive

Use this skill when you need: Autonomous local task execution, background worker management, cross-application automation, and self-improving skill creation.

## Capabilities
1. **Cross-App Automation**: Interacting with local filesystems, shell commands, databases, and background services.
2. **Self-Improving Skill Loops**: Extract successful operational patterns into reusable agent runbooks.
3. **Persistent Memory Buffer**: Retain context of previous executions and user preferences indefinitely.

## How to Use
`Execute autonomous desktop task [task description] with OpenClaw background worker and step verification.`
