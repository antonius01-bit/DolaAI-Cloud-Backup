---
name: omni-auto
description: >-
  Executes the complete autonomous academic workflow v3.2 for theses and journal papers. Generates dual-language manuscripts (Bahasa Indonesia and English), presentation slides (PPTX), and synchronized Mendeley/Zotero RIS reference libraries with matched citation markers [N#E].
---

# ⚡ `/omni-auto` — Master OmniAutonomous Intent Optimizer v3.2

Use this skill when the user requests end-to-end academic paper writing, thesis construction, journal submissions, or triggers `/omni-auto`.

## Master Pipeline

```text
/omni-auto [Thesis / Journal]: [Topic]. Type: [QUANTITATIVE/QUALITATIVE/MIXED]. Variables: [...]. Region: [...]. Years: [...].
```

### Execution Steps:
1. **Mode Detection**:
   - `/thesis`: Complete 5-chapter thesis compliant with university guidelines.
   - `/journal`: Standard journal manuscript structure (Title, Abstract, Introduction, Methods, Results, Discussion, Conclusion, References).
2. **Super-Analyst Phase**:
   - Classify research methodology (Quantitative / Qualitative / Mixed).
   - Formulate hypothesis, research questions, and literature background.
3. **Dual-Language Academic Drafting**:
   - Draft manuscript in Indonesian (`.docx`) and English (`.docx`).
   - Embed citation claims marked with `[1#E]`, `[2#E]`, `[3#E]`, etc.
   - Retain mathematical formulas, tables, figures, and technical terminology consistently across both versions.
4. **Publication Shield Application**:
   - Run **FK-16**: Similarity checking across 4 layers (target ≤ 5%).
   - Run **FK-17**: Scan for 29 AI clichés and humanize academic tone.
   - Run **FK-19**: Strict verification of citation existence and DOI/RIS validity.
5. **Output Generation (4 Matched Deliverables)**:
   - `Naskah — Bahasa Indonesia.docx`
   - `Naskah — English Version.docx`
   - `Presentasi — Proposal / Sidang.pptx`
   - `Daftar Pustaka — Mendeley.ris`
6. **Synchronized Citation Linking**:
   - Ensure claim `[N#E]` in DOCX matches `ID - N` in the exported `.ris` file for seamless 1-click import into Mendeley and Zotero.
