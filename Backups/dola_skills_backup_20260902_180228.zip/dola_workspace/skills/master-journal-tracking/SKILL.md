---
name: master-journal-tracking
description: >-
  Academic journal tracking, manuscript revision management, peer-review rebuttal formulation, diff tracking, and submission lifecycle auditing.
---

# 📰 Master Journal Tracking & Reviewer Response

Use this skill when managing academic journal submissions, addressing peer review comments, writing polite point-by-point rebuttal letters, or tracking manuscript revisions.

## Procedures

### 1. Peer Review Comment Matrix
Extract and catalog all reviewer comments into an action matrix:
| # | Reviewer | Comment Summary | Planned Change | Target Manuscript Location | Status |
|---|---|---|---|---|---|
| R1.1 | Reviewer 1 | Clarify sample size selection | Add power analysis paragraph in Section 2.3 | Section 2.3, Page 6 | Done |
| R1.2 | Reviewer 1 | Update references to 2024-2026 | Added 8 recent indexed papers | References & Table 1 | Done |

### 2. Point-by-Point Rebuttal Generator
Generate courteous, structured, and evidenced responses:
- **Gratitude & Understanding**: Acknowledge the reviewer's valuable insight.
- **Detailed Action**: Explain the precise amendments made.
- **Diff / Code Excerpt**: Display the exact before-and-after text changes.
