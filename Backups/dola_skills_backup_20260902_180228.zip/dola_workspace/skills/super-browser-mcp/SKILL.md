---
name: super-browser-mcp
description: >-
  Advanced browser automation, deep DOM inspection, multi-page data extraction, session state persistence, and visual verification combining Browser-Use, Puppeteer, and Chrome DevTools MCP capabilities.
---

# 🌐 Super Browser MCP (Browser-Use + DevTools Fusion)

Use this skill when automating complex web tasks, scraping dynamic web applications, filling multi-step forms, or performing visual web testing.

## Capabilities
1. **Intelligent DOM Exploration**: Locates elements by semantic labels, accessibility trees (ARIA), and visual coordinates.
2. **Multi-Page & Authenticated Sessions**: Retains cookies, storage, and session tokens across multi-turn workflows.
3. **Resilient Data Extraction**: Converts complex HTML tables, lazy-loaded feeds, and SPAs into structured JSON/Markdown.
4. **Network & Console Diagnostics**: Captures network payloads, detects failed requests, and parses browser console logs.
