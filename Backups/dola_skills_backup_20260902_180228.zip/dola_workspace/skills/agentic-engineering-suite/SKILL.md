---
name: agentic-engineering-suite
description: >-
  High-performance software engineering methodology combining Superpowers, ECC (Engineering Control Center), and Andrej Karpathy's LLM coding rules for zero-regression, hypothesis-driven development.
---

# 🚀 Agentic Engineering Suite (Superpowers + ECC + Karpathy Rules)

Use this skill when developing complex software projects, resolving tricky bugs, writing refactors, or running autonomous pair-programming sprints.

## Methodology & Rules
1. **Hypothesis-Driven Debugging**: Formulate explicit hypotheses before modifying code; verify root causes with logs or targeted tests.
2. **Minimal Surgical Modifications**: Never rewrite whole files when editing a few lines suffices. Preserve existing formatting and surrounding comments.
3. **Continuous Sub-Task Verification**: Verify every atomic step before moving to the next task in a plan.
4. **Architectural Coherence**: Adhere to the host repository's patterns, naming conventions, and lint configurations.
