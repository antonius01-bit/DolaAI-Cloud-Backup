---
name: langgraph-orchestrator
description: >-
  Multi-agent cyclic state-machine orchestration with checkpointing, human-in-the-loop validation, and fault-tolerant branching.
---

# ⚡ LangGraph Stateful Agent Orchestrator

Use this skill when you need: Multi-agent cyclic state-machine orchestration with checkpointing, human-in-the-loop validation, and fault-tolerant branching.

## Capabilities
1. **Cyclic State Graphs**: Build agents with loopbacks, retries, and conditional branching rather than rigid linear chains.
2. **Persistence & Checkpointing**: Save execution state at every node for instant resumption and rewind.
3. **Multi-Agent Collaboration**: Coordinate specialist nodes (Researcher, Coder, Critic, Synthesizer) sharing a global typed state.
4. **Human-in-the-Loop Interruption**: Pause graph execution for user confirmation before executing high-stakes tool calls.

## How to Use
`Design stateful multi-agent workflow for [task] using LangGraph state graphs, node execution, and checkpoint memory.`
