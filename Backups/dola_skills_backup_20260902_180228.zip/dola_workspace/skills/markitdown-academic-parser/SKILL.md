---
name: markitdown-academic-parser
description: >-
  High-fidelity document conversion engine based on Microsoft MarkItDown for converting DOCX, PPTX, XLSX, PDF, HTML, and audio/video transcripts into clean, structure-preserving Markdown for LLM analysis.
---

# 📄 MarkItDown Academic & Office Document Parser

Use this skill when converting complex office files (DOCX, PPTX, XLSX, PDF), scientific papers, or presentations into clean, formatted Markdown for agent consumption.

## Supported Formats & Extraction
- **Word Documents (`.docx`)**: Preserves heading hierarchy, tables, inline citations, bold/italic, and footnotes.
- **PowerPoint Decks (`.pptx`)**: Extracts slide titles, bullet points, presenter speaker notes, and embedded charts.
- **Excel Spreadsheets (`.xlsx`)**: Transforms sheets into structured Markdown tables with column headers.
- **PDF Documents (`.pdf`)**: Extracts text flow, mathematical formulas, and multi-column academic layouts without broken line wraps.
