---
name: publication-shield
description: >-
  Triple-layer academic protection engine providing FK-16 similarity/plagiarism auditing (target <= 5%), FK-17 29 AI cliché pattern scanning with natural humanization, and FK-19 authentic citation verification.
---

# 🛡️ Publication Shield (FK-16 / FK-17 / FK-19)

Use this skill when auditing academic manuscripts, checking for AI patterns or plagiarism, humanizing text, or verifying citation authenticity.

## Triple-Protection Modules

### 1. FK-16: 4-Layer Similarity & Plagiarism Audit
- **Layer 1 (Exact Match)**: Identifies verbatim phrases and rephrases into original synthesis.
- **Layer 2 (Sentence Structure)**: Detects copied syntactic patterns and reorganizes discourse flow.
- **Layer 3 (Core Concept Repetition)**: Ensures unique framing and avoids repetitive ideas.
- **Layer 4 (Database Cross-Check)**: Verifies against standard academic literature patterns to achieve similarity $\le 5\%$.

### 2. FK-17: 29 AI Pattern Scan & Humanization
- Scans for robotic AI markers (e.g., "delves into", "tapestry", "multifaceted", "it is important to note", "testament to").
- Eliminates superficial transitions, excessive adverbs, and repetitive cadence.
- Implements active academic voice, concise reasoning, and natural authorial tone.

### 3. FK-19: Citation & Fact Authentication
- Confirms that every referenced author, year, title, and DOI actually exists in recognized databases (CrossRef, Scopus, Google Scholar, PubMed).
- Rejects hallucinated or fabricated citations.
- Locks formatting to APA 7th, IEEE, or journal-specific standards.
