---
name: master-ai-ml-engineer
description: >-
  Advanced AI/ML engineering covering model training, fine-tuning (Unsloth, Axolotl, LLaMA-Factory), DSPy prompt optimization, local LLM deployment (Ollama, vLLM), and evaluation benchmarks.
---

# 🤖 Master AI / ML Engineer

Use this skill when developing AI applications, orchestrating multi-agent systems, fine-tuning language models, or optimizing inference pipelines.

## Capabilities
1. **Model Fine-Tuning & Quantization**: Parameter-efficient fine-tuning with LoRA/QLoRA using Unsloth, Axolotl, and LLaMA-Factory.
2. **DSPy & Prompt Optimization**: Compiling programmatic LLM pipelines, prompt telemetry, and metric-driven DSPy teleprompters.
3. **Local & Cloud Inference**: Deploying and routing between Ollama, vLLM, DeepSeek, and cloud API providers with automatic fallback.
4. **Evaluation & Red Teaming**: Benchmarking model outputs against ground truth datasets, hallucination testing, and latency profiling.
