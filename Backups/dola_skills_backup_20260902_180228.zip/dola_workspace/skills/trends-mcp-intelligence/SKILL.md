---
name: trends-mcp-intelligence
description: >-
  Real-time GitHub trending, tech radar analytics, and developer social signal intelligence via Model Context Protocol.
---

# ⚡ Trends MCP Live Intelligence Harvester

Use this skill when you need: Real-time GitHub trending, tech radar analytics, and developer social signal intelligence via Model Context Protocol.

## Capabilities
1. **Live GitHub Trending Scraper**: Pulls daily/weekly trending repositories across any language or topic.
2. **Technology Radar Analysis**: Identifies fast-growing AI repositories and emerging developer frameworks.
3. **Automated Digest Generator**: Synthesizes market movements into structured executive markdown tables.

## How to Use
`Fetch live GitHub trending repositories and tech signals for [topic/language] via Trends MCP.`
